import React, {Component} from 'react';
import PropTypes from 'prop-types';

export default class Home extends Component {
  static propTypes = {
    dispatch: PropTypes.any,
  }

  constructor(props) {
    super(props);
    this.state = {
      traveller: {x: 4, y: 4}
    };
    this.createMap = this.createMap.bind(this);
  }

  createMap() {
    const map = [];
    for (let idx = 0; idx < 9; idx++) {
      for (let jdx = 0; jdx < 9; jdx++) {
        if ((idx === 2 && jdx === 2) || (idx === 6 && jdx === 3) || (idx === 3 && jdx === 8)) {
          map.push({x: idx, y: jdx, value: 'G'});
        } else if (idx === 4 && jdx === 4) {
          map.push({x: idx, y: jdx, value: 'T'});
        } else {
          map.push({x: idx, y: jdx, value: '.'});
        }
      }
    }
  }

  direction(number, letter) {
    let value = 0;
    switch (letter) {
      case 'e':
        value = this.state.traveller.y + number;
        this.state.traveller.y = value;
        if (value > 8) {
          this.state.traveller.y = 8;
        }
        break;
      case 's':
        value = this.state.traveller.x + number;
        this.state.traveller.x = value;
        if (value > 8) {
          this.state.traveller.x = 8;
        }
        break;
      case 'w':
        value = this.state.traveller.y - number;
        this.state.traveller.y = value;
        if (value < 0) {
          this.state.traveller.y = 0;
        }
        break;
      case 'n':
        value = this.state.traveller.x - number;
        this.state.traveller.x = value;
        if (value < 0) {
          this.state.traveller.x = 0;
        }
        break;
      default:
        return 0;
    }
    return 1;
  }

  checkGobelinPosition() {
    if ((this.state.traveller.x === 2 && this.state.traveller.y === 2)
    || (this.state.traveller.x === 6 && this.state.traveller.y === 3)
    || (this.state.traveller.x === 3 && this.state.traveller.y === 8)) {
      return true;
    }
    return false;
  }

  reset() {
    this.state.traveller.x = 4;
    this.state.traveller.y = 4;
  }

  move() {
    this.createMap();
    let returnValue = '';
    for (let idx = 0; idx < arguments.length; idx++) {
      // parse on array
      if (typeof arguments[idx] === 'object') {
        for (let jdx = 0; jdx < arguments[0].length; jdx++) {
          this.direction(arguments[0][jdx].split('')[0], arguments[0][jdx].split('')[1]);
        }
        returnValue = [this.state.traveller.x + ', ' + this.state.traveller.y];
      } else if (arguments[idx].length > 2) {
        returnValue = 'Wrong type arguments';
      } else if (arguments[idx].length < 2) {
        this.direction(1, arguments[idx][0]);
        returnValue = [this.state.traveller.x + ', ' + this.state.traveller.y];
      } else {
        // begin to parse 1n, 8e...
        this.direction(arguments[idx].split('')[0], arguments[idx].split('')[1]);
        returnValue = [this.state.traveller.x + ', ' + this.state.traveller.y];
      }
    }
    if (this.checkGobelinPosition()) {
      console.log('dead');
    } else {
      console.log(returnValue);
    }
    return returnValue;
  }

  render() {
    const styles = require('./Home.scss');
    return (
      <div className={styles.home}>
        <button value="Move" onClick={() => this.move('2n', '3w')} className={styles.buttonMove}>Let play the game</button>
      </div>
    );
  }
}
